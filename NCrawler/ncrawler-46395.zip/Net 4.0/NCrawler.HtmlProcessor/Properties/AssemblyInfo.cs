﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Resources;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("NCrawler.HtmlProcessor")]
[assembly: AssemblyDescription("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("35624dc4-d018-4778-a5d7-88eea7e0782b")]
[assembly: NeutralResourcesLanguageAttribute("en-US")]
