﻿ALTER DATABASE [$(DatabaseName)]
    ADD FILE (NAME = [NCrawler], FILENAME = '$(Path2)NCrawler.mdf', FILEGROWTH = 1024 KB) TO FILEGROUP [PRIMARY];

